//
//  ProfileCell.m
//  Babysitter
//
//  Created by Torrent on 12/25/15.
//  Copyright © 2015 Donka. All rights reserved.
//

#import "ProfileCell.h"

@implementation ProfileCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
